---
name: Stock balance semantics
description: Business rule for a store/barcode's current balance and sales between physical visits.
---

For each store and barcode, a physical visit records the current total and becomes the balance baseline. Stock inputs and original receipt quantities after that visit adjust the baseline; if no visit exists, all stock inputs and receipts contribute. A late invoice is matched to the existing receipt, which remains unchanged; only the signed difference between invoiced and received quantity is applied when the invoice is recorded. Editing a match replaces that adjustment instead of adding another one. Sales intervals attribute a receipt to its receipt time and the invoice difference to its recording time.

The user confirmed on 2026-10-04 that the two production visits recording 1 unit after the 500-unit receipt are both correct. Do not treat those counts as errors or correct them based only on the earlier receipt.

**Why:** the user specified that stock input and receipts add while a visit replaces the physical baseline, that late invoices must reconcile to an existing receipt by adjusting only the difference without double-counting, and confirmed those later physical counts are valid.

**How to apply:** keep on-hand balance and sales calculations consistent across the API and screens. Apply invoice deltas at recording time so a late invoice can adjust stock even when a physical visit happened after the original receipt.