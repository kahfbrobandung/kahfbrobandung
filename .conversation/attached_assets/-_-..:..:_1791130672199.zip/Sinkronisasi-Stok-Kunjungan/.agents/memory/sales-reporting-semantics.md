---
name: Sales reporting semantics
description: User-selected scope for the store's daily sales report.
---

The daily sales report must show recorded transactions whose type is `Penjualan` only. Do not infer or estimate sales from stocktake counts in this report, and do not add charts; show the transaction data.

**Why:** the user explicitly chose daily recorded sales transactions and asked for data only, without graphs.

**How to apply:** keep this rule specific to the daily transaction report; any separate stocktake-based estimate feature must be labeled and presented independently.