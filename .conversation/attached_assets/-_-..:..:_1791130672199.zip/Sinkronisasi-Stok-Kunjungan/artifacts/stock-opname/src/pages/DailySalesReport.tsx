import { useMemo, useState } from "react";
import { Link } from "wouter";
import {
  getGetDailySalesQueryKey,
  getListStoresQueryKey,
  useGetDailySales,
  useListStores,
  type GetDailySalesParams,
} from "@workspace/api-client-react";
import { ArrowLeft, CalendarDays, RefreshCw } from "lucide-react";

const number = (value: number) => new Intl.NumberFormat("id-ID").format(value);

function jakartaDate(value: Date) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Jakarta",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(value);
  return `${parts.find((part) => part.type === "year")?.value}-${parts.find((part) => part.type === "month")?.value}-${parts.find((part) => part.type === "day")?.value}`;
}

function shiftDate(value: string, days: number) {
  const [year, month, day] = value.split("-").map(Number);
  const date = new Date(Date.UTC(year, month - 1, day + days));
  return date.toISOString().slice(0, 10);
}

function jakartaTimestamp(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? "—"
    : new Intl.DateTimeFormat("id-ID", {
        timeZone: "Asia/Jakarta",
        dateStyle: "medium",
        timeStyle: "short",
      }).format(date);
}

export default function DailySalesReport() {
  const today = useMemo(() => jakartaDate(new Date()), []);
  const [from, setFrom] = useState(() => shiftDate(jakartaDate(new Date()), -6));
  const [to, setTo] = useState(today);
  const [selectedStore, setSelectedStore] = useState("");

  const storesQuery = useListStores({
    query: {
      queryKey: getListStoresQueryKey(),
      staleTime: 5 * 60 * 1000,
    },
  });
  const validRange = Boolean(from && to && from <= to);
  const params: GetDailySalesParams = useMemo(() => ({
    from,
    to,
    limit: 5000,
    ...(selectedStore ? { store: selectedStore } : {}),
  }), [from, to, selectedStore]);
  const salesQuery = useGetDailySales(params, {
    query: {
      queryKey: getGetDailySalesQueryKey(params),
      enabled: validRange,
      staleTime: 30_000,
    },
  });
  const transactions = salesQuery.data ?? [];

  return (
    <main className="min-h-[100dvh] bg-background px-4 py-6 text-foreground sm:px-6">
      <div className="mx-auto max-w-7xl">
        <header className="mb-6 flex flex-col gap-4 border-b border-border pb-5 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <Link href="/" className="mb-3 inline-flex items-center gap-2 text-xs font-semibold text-muted-foreground hover:text-foreground">
              <ArrowLeft className="h-3.5 w-3.5" /> Beranda
            </Link>
            <p className="text-[10px] font-bold uppercase tracking-[0.17em] text-[#8a7856]">Data transaksi</p>
            <h1 className="mt-1 font-serif text-3xl font-bold tracking-tight">Penjualan harian</h1>
            <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
              Hanya menampilkan transaksi yang dicatat sebagai Penjualan, sesuai tanggal dan toko yang dipilih.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Link
              href="/operasional"
              className="inline-flex h-10 items-center gap-2 rounded-lg border border-border bg-card px-3 text-sm font-semibold hover:bg-muted"
              data-testid="link-operations"
            >
              Operasional
            </Link>
            <button
              type="button"
              onClick={() => salesQuery.refetch()}
              disabled={!validRange || salesQuery.isFetching}
              className="inline-flex h-10 items-center gap-2 rounded-lg bg-primary px-3 text-sm font-semibold text-primary-foreground disabled:opacity-50"
              data-testid="button-refresh-daily-sales"
            >
              <RefreshCw className={`h-4 w-4 ${salesQuery.isFetching ? "animate-spin" : ""}`} />
              Muat ulang
            </button>
          </div>
        </header>

        <section className="mb-5 rounded-2xl border border-border bg-card p-4 sm:p-5" aria-label="Filter laporan penjualan">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-[1fr_1fr_1.2fr_auto] lg:items-end">
            <label className="text-xs font-semibold">
              Dari tanggal
              <span className="relative mt-1 block">
                <CalendarDays className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="date"
                  value={from}
                  max={to || undefined}
                  onChange={(event) => setFrom(event.target.value)}
                  className="h-10 w-full rounded-lg border border-input bg-background pl-9 pr-3 text-sm font-normal"
                  data-testid="input-sales-from"
                />
              </span>
            </label>
            <label className="text-xs font-semibold">
              Sampai tanggal
              <span className="relative mt-1 block">
                <CalendarDays className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="date"
                  value={to}
                  min={from || undefined}
                  onChange={(event) => setTo(event.target.value)}
                  className="h-10 w-full rounded-lg border border-input bg-background pl-9 pr-3 text-sm font-normal"
                  data-testid="input-sales-to"
                />
              </span>
            </label>
            <label className="text-xs font-semibold">
              Toko
              <select
                value={selectedStore}
                onChange={(event) => setSelectedStore(event.target.value)}
                className="mt-1 h-10 w-full rounded-lg border border-input bg-background px-3 text-sm font-normal"
                data-testid="select-sales-store"
              >
                <option value="">Semua toko</option>
                {(storesQuery.data ?? []).map((store) => (
                  <option key={store.name} value={store.name}>{store.name}</option>
                ))}
              </select>
            </label>
            <p className="pb-2 text-xs text-muted-foreground lg:text-right">
              Zona waktu Asia/Jakarta
            </p>
          </div>
          {!validRange && (
            <p className="mt-3 text-sm text-destructive" role="alert" data-testid="status-invalid-date-range">
              Tanggal mulai harus sama dengan atau sebelum tanggal akhir.
            </p>
          )}
        </section>

        <section className="overflow-hidden rounded-2xl border border-border bg-card" aria-label="Daftar transaksi penjualan">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border px-4 py-3 sm:px-5">
            <div>
              <h2 className="font-serif text-lg font-bold">Catatan transaksi</h2>
              <p className="text-xs text-muted-foreground">{selectedStore || "Semua toko"} · {from} sampai {to}</p>
            </div>
            {!salesQuery.isLoading && !salesQuery.isError && validRange && (
              <span className="text-xs font-semibold text-muted-foreground" data-testid="text-daily-sales-count">
                {number(transactions.length)} transaksi
              </span>
            )}
          </div>

          {salesQuery.isError ? (
            <div className="px-5 py-10 text-center" role="alert" data-testid="status-daily-sales-error">
              <p className="text-sm font-semibold">Transaksi penjualan tidak dapat dimuat.</p>
              <button type="button" onClick={() => salesQuery.refetch()} className="mt-2 text-sm font-semibold text-primary underline underline-offset-2">
                Coba lagi
              </button>
            </div>
          ) : !validRange ? (
            <p className="px-5 py-10 text-center text-sm text-muted-foreground">Periksa rentang tanggal untuk melihat transaksi.</p>
          ) : salesQuery.isLoading ? (
            <div className="space-y-3 p-5" aria-label="Memuat transaksi">
              <div className="h-9 animate-pulse rounded-lg bg-muted" />
              {[0, 1, 2, 3].map((item) => <div key={item} className="h-12 animate-pulse rounded-lg bg-muted" />)}
            </div>
          ) : transactions.length === 0 ? (
            <p className="px-5 py-12 text-center text-sm text-muted-foreground" data-testid="status-daily-sales-empty">
              Tidak ada transaksi Penjualan pada rentang tanggal dan toko yang dipilih.
            </p>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[980px] text-left text-sm">
                  <thead className="border-b border-border bg-muted/50 text-[10px] uppercase tracking-[0.12em] text-muted-foreground">
                    <tr>
                      <th className="px-4 py-3 font-bold sm:px-5">Waktu</th>
                      <th className="px-4 py-3 font-bold">Toko</th>
                      <th className="px-4 py-3 font-bold">Produk / barcode</th>
                      <th className="px-4 py-3 font-bold">Jenis</th>
                      <th className="px-4 py-3 text-right font-bold">Jumlah</th>
                      <th className="px-4 py-3 text-right font-bold">Display</th>
                      <th className="px-4 py-3 text-right font-bold">Display sekunder</th>
                      <th className="px-4 py-3 text-right font-bold sm:px-5">Gudang</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {transactions.map((transaction) => (
                      <tr key={transaction.id} className="transition-colors hover:bg-muted/30" data-testid={`row-daily-sale-${transaction.id}`}>
                        <td className="whitespace-nowrap px-4 py-3.5 text-xs text-muted-foreground sm:px-5">{jakartaTimestamp(transaction.createdAt)}</td>
                        <td className="px-4 py-3.5 font-medium">{transaction.store}</td>
                        <td className="px-4 py-3.5">
                          <span className="block font-semibold">{transaction.product}</span>
                          <span className="mt-0.5 block font-mono text-xs text-muted-foreground">{transaction.barcode}</span>
                        </td>
                        <td className="px-4 py-3.5">
                          <span className="rounded-full bg-[#315b48]/10 px-2 py-1 text-[10px] font-bold text-[#315b48] dark:text-[#a9d2b8]">Penjualan</span>
                        </td>
                        <td className="px-4 py-3.5 text-right font-mono font-bold">{number(transaction.quantity)}</td>
                        <td className="px-4 py-3.5 text-right font-mono">{number(transaction.displayQuantity)}</td>
                        <td className="px-4 py-3.5 text-right font-mono">{number(transaction.secondaryDisplayQuantity)}</td>
                        <td className="px-4 py-3.5 text-right font-mono sm:px-5">{number(transaction.warehouseQuantity)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="border-t border-border px-4 py-3 text-xs text-muted-foreground sm:px-5" data-testid="text-daily-sales-note">
                {transactions.length === 5000
                  ? "Menampilkan 5.000 transaksi terbaru. Persempit tanggal atau pilih toko untuk melihat catatan lainnya."
                  : `${number(transactions.length)} transaksi tercatat; jumlah dalam unit.`}
              </p>
            </>
          )}
        </section>
      </div>
    </main>
  );
}